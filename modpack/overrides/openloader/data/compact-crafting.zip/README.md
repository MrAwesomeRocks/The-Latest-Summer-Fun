# compact-recipes
Integration datapack between Compact Machines and Compact Crafting.

This version is for Compact Crafting betas and Compact Machines 4.

Find the latest versions here: https://github.com/CompactMods/compact-recipes
